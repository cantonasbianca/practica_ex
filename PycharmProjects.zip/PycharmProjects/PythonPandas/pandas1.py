import pandas as pd

data = { "Date": [ "2024-01-05", "2024-01-07", "2024-01-10", "2024-01-15", "2024-02-01", "2024-02-08", "2024-02-12", "2024-02-20" ],
         "Type": ["Income", "Expense", "Expense", "Income", "Income", "Expense", "Expense", "Expense"],
         "Category": ["Salary", "Groceries", "Utilities", "Freelance", "Salary", "Rent", "Entertainment", "Groceries"],
         "Amount": [4000, -150, -90, 500, 4000, -1200, -200, -160] }


df = pd.DataFrame(data)
print(df)
filtrare = df[df['Type'] == 'Expense']
print(filtrare)
total_income = df[df['Type'] == 'Income']['Amount']
print(total_income.sum())
total_expense = df[df['Type'] == 'Expense']['Amount']
print(total_expense.sum())

df['Balance'] = df['Amount'].cumsum()
print(df)
grup = df.groupby('Category')['Amount'].sum()
print(grup)
grup_medie = df.groupby('Type')['Amount'].mean()
print("grup_medie\n")
print(grup_medie)
ordonare = df.sort_values(by='Amount', ascending = False)
print(ordonare)
filtrare2 = df[abs(df['Amount'])>300]
print(filtrare2)
df["Date"] = pd.to_datetime(df["Date"])
df['Luna'] = df['Date'].dt.to_period('M')
cheltuieli_lunare = df[df['Type']=='Expense'].groupby('Luna')['Amount'].sum()
print(cheltuieli_lunare)
df['Noua_coloana'] = abs(df['Amount'])
print(df)
ordonare_tranzactii = df.sort_values(by='Noua_coloana', ascending = True)
print(ordonare_tranzactii)
cheltuieli_totale = df[df['Type'] == 'Expense']['Amount'].sum()
print(cheltuieli_totale)
procent_categorie = (df[df['Type'] == 'Expense'].groupby('Category')['Amount'].sum() / cheltuieli_totale) * 100
print(procent_categorie)


