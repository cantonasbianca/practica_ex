import pandas as pd
import plotly
import plotly.express as px
import plotly.io as pio

data ={
    'Language': ['English', 'Mandarin', 'Hindi', 'Spanish', 'French', 'Arabic', 'Bengali', 'Russian', 'Portuguese', 'Others'],
    'Speakers (millions)': [1500, 1117, 615, 534, 280, 274, 273, 258, 234, 1000],
    'Region/Countries': [ 'Worldwide', 'China, Taiwan, Singapore', 'India, Nepal, Fiji', 'Spain, Latin America', 'France, Canada, Africa', 'Middle East, North Africa', 'Bangladesh, India', 'Russia, Eastern Europe', 'Brazil, Portugal, Africa', 'Various' ],
    'Dialects': [160, 10, 50, 20, 30, 25, 12, 15, 21, 100] }

df = pd.DataFrame(data)
print(df)

df_top5 = df.sort_values(by='Speakers (millions)', ascending=False).head(5)
print(df_top5)

pie_chart = px.pie(
        data_frame=df_top5,
        values='Speakers (millions)',
        names='Language',
        color_discrete_sequence=px.colors.sequential.RdBu,
        hover_data= ['Dialects', 'Region/Countries'],
        title='Language spoken around the glob',
        )

pie_chart.update_traces(
    textinfo='label+percent',
    hovertemplate="<b>%{label}</b><br>Speakers: %{value}M<br>Dialects: %{customdata[0][0]}<br>Region: %{customdata[0][1]}",
    pull=[0.2, 0, 0, 0, 0.2])


pie_chart.show()