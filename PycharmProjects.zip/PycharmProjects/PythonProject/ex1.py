'''def salariu_net(brut=3300):
    cas = brut * 0.25
    cass = brut * 0.10
    impozit = brut * 0.10
    net =  brut - cas - cass - impozit
    print(net)

salariu_net()'''


'''def salariu(brut):
    if brut < 3000:
        impozit = brut * 0.40
        net = brut - impozit
        print(net)
    elif 3000 <= brut <= 8000:
        impozit = brut * 0.45
        net = brut - impozit
        print(net)
    elif brut > 8000:
        impozit = brut * 0.50
        net = brut - impozit
        print(net)
salariu(3000)'''

