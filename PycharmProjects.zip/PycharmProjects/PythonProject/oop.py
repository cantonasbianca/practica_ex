class Student:
  def __init__(self, varsta, nume):
    self.varsta = varsta
    self.nume =  nume

  def salut(self):
    print ("Salut, eu sunt " + self.nume)

  def minor_major(self):
    if self.varsta < 18:
      print("Studentul este minor")
    else:
      print("Studentul nu este major")

s1 = Student(20, 'Bianca')
s2 = Student(16, 'Radu')
s3 = Student(24, 'Ioana')

s1.salut()
s2.salut()
s3.salut()
s1.minor_major()
s2.minor_major()
s3.minor_major()

s1.varsta = 25
print("Varsta corecta este ", s1.varsta)

