class Motor:
    def __init__(self, tip_motor):
        self.tip_motor = tip_motor
        self.staremotor = False
    def porneste(self):
        self.staremotor = True
        print('Motorul este pornit')
    def opreste(self):
        self.staremotor = False
        print('Motorul este oprit')

    def __eq__(self,other):
        if isinstance(other, Motor):
            return self.tip_motor == other.tip_motor
        return False

class Masina:
    def __init__(self, model, motor):
        self.motor = motor
        self.model = model
    def __str__(self):
        return f"Masina {self.model} are motorul {self.motor.tip_motor}"
    def porneste_motor(self):
        self.motor.porneste()
    def opreste_motor(self):
        self.motor.opreste()
    def __eq__(self,other):
        if isinstance(other, Masina):
            return self.model == other.model and  self.motor == other.motor
        return False
motor=Motor("V6")
masina1=Masina("BMW", motor)
masina2=Masina("Audi", "V8")
masina3=Masina("Audi", "V8")
masina1.porneste_motor()
masina1.opreste_motor()
print(str(masina1))
print(masina1==masina2)
print(masina2==masina3)
