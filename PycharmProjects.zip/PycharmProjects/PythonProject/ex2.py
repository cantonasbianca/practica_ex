def calcul_pensie(investitie, luna, dobanda)
    