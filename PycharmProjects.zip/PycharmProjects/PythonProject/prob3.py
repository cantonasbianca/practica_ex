class Animal:
    def sunet(self):
        pass

class Caine(Animal):
    def sunet(self):
        print("Ham Ham")

class Pisica(Animal):
    def __init__(self, cip):
        self.__cip = cip
    def get_cip(self):
        return self.__cip

    def set_cip(self, alt_cip):
        self.__cip = alt_cip

    def sunet(self):
        print("Miau Miau")

c=Caine()
p=Pisica(432)
c.sunet()
p.sunet()

lista=[c, p]
for animal in lista:
    animal.sunet()

print(p.get_cip())
p.set_cip(555)
print(p.get_cip())