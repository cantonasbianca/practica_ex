class Carte:
  def __init__(self, titlu, autor, anul_publicarii):
    self.autor = autor
    self.titlu =  titlu
    self.anul_publicarii = anul_publicarii

  def descriere(self):
      print("Titlul este: ", self.titlu, "Autorul este: ", self.autor, "Anul publicatiei este: ", self.anul_publicarii)

c1=Carte("Moara cu noroc", "Ioan Slavici", 1881)
c1.descriere()

class Biblioteca:
    def __init__(self,lista):
        self.lista = lista

    def adaugare_carte(self,carte):
        self.lista.append(carte)

    def listare_carti(self):
        for carte in self.lista:
            carte.descriere()

    def cautare_carte(self, titlu_cautat):
        for carte in self.lista:
            if carte.titlu == titlu_cautat():
                print("Cartea este gasita", carte)
                return
            else:
                print("Cartea nu este gasita")

c2= Carte("Baltagul", "Mihail Sadoveanu", 1930)
b1=Biblioteca([])
b1.adaugare_carte(c1)
b1.adaugare_carte(c2)
b1.listare_carti()
b1.cautare_carte("Baltagul")
b1.cautare_carte("Ion")